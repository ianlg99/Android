package mx.mauriciogs.consumiendoapi.data.model

data class Location(
    val name: String,
    val url: String
)