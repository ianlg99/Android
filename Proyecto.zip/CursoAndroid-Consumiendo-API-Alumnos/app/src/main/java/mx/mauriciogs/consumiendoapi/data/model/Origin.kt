package mx.mauriciogs.consumiendoapi.data.model

data class Origin(
    val name: String,
    val url: String
)